package com.sakha.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sakha.service.Updateemployeeservice;

/**
 * Servlet implementation class UpadateEmployeeController
 */
@WebServlet("/UpadateEmployeeController")
public class UpadateEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpadateEmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String empId = request.getParameter("empid");
		float salary= Float.parseFloat(request.getParameter("salary"));
		Updateemployeeservice ue= new Updateemployeeservice();
		
		try {
			boolean b= ue.updateemployee(empId, salary);
			if(b)
			{
				request.getSession().setAttribute("success", "Updated successfully");
			}
			else
			{
				request.getSession().setAttribute("error", "no employee to update");
			}
			response.sendRedirect("update.jsp");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
