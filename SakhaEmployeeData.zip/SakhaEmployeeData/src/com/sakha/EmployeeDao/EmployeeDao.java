package com.sakha.EmployeeDao;

import java.sql.Connection;
import java.util.List;

import com.sakha.Model.Employee;

public interface EmployeeDao {
	public Connection getConnection()throws Exception;
	public boolean addemployee(Employee e)throws Exception ;
	public boolean deleteemployee(String empId)throws Exception;
	public Employee getEmp(String empId) throws Exception;
	public List<Employee> getAllEmployee() throws Exception;
	//public boolean updateemployee(String empId) throws Exception;
	boolean updateemployee(String empId, float salary) throws Exception;
}
