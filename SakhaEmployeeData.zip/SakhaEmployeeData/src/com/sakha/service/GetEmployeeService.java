package com.sakha.service;

import com.sakha.EmployeeDao.EmployeeDao;
import com.sakha.EmployeeDao.EmployeeDaoimpl;
import com.sakha.Model.Employee;

public class GetEmployeeService {
	
	EmployeeDao dao= new EmployeeDaoimpl();
	public Employee getEmployee(String empid)throws Exception{
		return dao.getEmp(empid);
		
	}

}
