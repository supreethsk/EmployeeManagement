package com.sakha.service;

import com.sakha.EmployeeDao.EmployeeDao;
import com.sakha.EmployeeDao.EmployeeDaoimpl;

public class Updateemployeeservice {
	EmployeeDao dao= new EmployeeDaoimpl();
	public boolean updateemployee(String empId ,float salary) throws Exception{
		
		return dao.updateemployee(empId,salary);
	}
}
