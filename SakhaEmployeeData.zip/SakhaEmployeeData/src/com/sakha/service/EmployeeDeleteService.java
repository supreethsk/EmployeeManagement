package com.sakha.service;

import com.sakha.EmployeeDao.EmployeeDao;
import com.sakha.EmployeeDao.EmployeeDaoimpl;

public class EmployeeDeleteService {
	EmployeeDao dao= new EmployeeDaoimpl();
public boolean delete(String empId) throws Exception{
	return dao.deleteemployee(empId);
}

}
