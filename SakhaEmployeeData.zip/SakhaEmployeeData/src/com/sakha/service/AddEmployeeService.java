package com.sakha.service;

import java.sql.Connection;
import java.util.Random;

import com.sakha.EmployeeDao.EmployeeDao;
import com.sakha.EmployeeDao.EmployeeDaoimpl;
import com.sakha.Model.Employee;

public class AddEmployeeService {
	EmployeeDao dao= new  EmployeeDaoimpl();
	public boolean addemployee(Employee e) throws Exception {
		//Connection con=dao.getConnection();
		return dao.addemployee(e);
		
	}
	
	public String generateId(String empName) {
		// TODO Auto-generated method stub
		String nameChar = empName.substring(0,2).toUpperCase();
		Random rand = new Random();
		int dgt = (int)(rand.nextDouble()*10000);
		return nameChar+dgt;
		//return null;
	}
}
