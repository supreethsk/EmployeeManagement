package com.sakha.service;

import java.util.List;

import com.sakha.EmployeeDao.EmployeeDao;
import com.sakha.EmployeeDao.EmployeeDaoimpl;
import com.sakha.Model.Employee;

public class GetAllEmployeeService {
	EmployeeDao dao = new EmployeeDaoimpl();
	public List<Employee> getAllEmployee() throws Exception
	{
		 return dao.getAllEmployee();
	}
}
